from typing import Any, Dict, List, Optional
from uuid import UUID

from flows_sdk.blocks import CodeBlock
from flows_sdk.flows import Flow, Parameter
from flows_sdk.implementations.idp_v32.idp_blocks import (
    CaseCollationBlock,
    FlexibleExtractionBlock,
    IDPOutputsBlock,
    MachineClassificationBlock,
    MachineIdentificationBlock,
    MachineTranscriptionBlock,
    ManualClassificationBlock,
    ManualIdentificationBlock,
    ManualTranscriptionBlock,
    SubmissionBootstrapBlock,
    SubmissionCompleteBlock,
)
from flows_sdk.implementations.idp_v32.idp_values import (
    IDPManifest,
    IDPTriggers,
    get_idp_wf_config,
    get_idp_wf_inputs,
)
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import workflow_input


class CustomSettings:
    SkipFlexibleExtraction = 'Skip Flexible Extraction For Validation Discrepancies'
    IgnoreLineItemTranscription = 'Ignore Table Fields Not Transcribed'


LINE_ITEM_VALIDATION_PARAMETERS: List[Parameter] = [
    Parameter(
        name=CustomSettings.SkipFlexibleExtraction,
        type='boolean',
        title=CustomSettings.SkipFlexibleExtraction,
        ui={'hidden': False},
        description='Check this box to skip Flexible Extraction when line item validation and '
                    'total amount discrepancies occur. Useful when downstream processes address any '
                    'discrepancies',
        optional=True,
    ),
    Parameter(
        name=CustomSettings.IgnoreLineItemTranscription,
        type='boolean',
        title=CustomSettings.IgnoreLineItemTranscription,
        ui={'hidden': False},
        description='Check this box to prevent columns_not_transcribed messages in the output',
        optional=True,
    ),
]


def entry_point_flow() -> Flow:
    return idp_workflow()


def idp_workflow() -> Flow:
    idp_wf_config = get_idp_wf_config()

    # The idp flow basically processes, modifies and propagates the submission object from
    # block to block
    # Each block's processing result is usually included in the submission object

    # Submission bootstrap block initializes the submission object and prepares external images
    # or other submission data if needed
    submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

    # Case collation block groups files, documents and pages (from the submission) into cases
    # In this example, case collation block receives the submission object and the cases
    # information from submission bootstrap block
    case_collation = CaseCollationBlock(
        reference_name='machine_collation',
        submission=submission_bootstrap.output('result.submission'),
        cases=submission_bootstrap.output('result.api_params.cases'),
    )

    # Machine classification block automatically matches documents to structured, semi-structured
    # or additional layouts
    # In this example, machine classification block receives the submission object from
    # case collation block
    machine_classification = MachineClassificationBlock(
        reference_name='machine_classification',
        submission=case_collation.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Manual classification block allows keyers to manually match submissions to their layouts.
    # Keyers may perform manual classification if machine classification cannot automatically
    # match a submission to a layout with high confidence
    # In this example, manual classification block receives the submission object from machine
    # classification block
    manual_classification = ManualClassificationBlock(
        reference_name='manual_classification',
        submission=machine_classification.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Machine identification automatically identify fields and tables in the submission
    # In this example, machine identification block receives the submission object from manual
    # classification
    machine_identification = MachineIdentificationBlock(
        reference_name='machine_identification',
        submission=manual_classification.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Manual identification allows keyers to complete field identification or table identification
    # tasks, where they draw bounding boxes around the contents of certain fields, table columns
    # or table rows. This identification process ensures that the system will be able to
    # transcribe the correct content in the upcoming transcription process
    # In this example, manual identification block receives the submission object from machine
    # identification
    manual_identification = ManualIdentificationBlock(
        reference_name='manual_identification',
        submission=machine_identification.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Machine transcription automatically transcribes the content of your submission
    # In this example, machine identification block receives the submission object from manual
    # identification
    machine_transcription = MachineTranscriptionBlock(
        reference_name='machine_transcription',
        submission=manual_identification.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Manual transcription lets your keyers manually enter the text found in fields or tables
    # that could not be automatically transcribed
    # In this example, manual transcription block receives the submission object from machine
    # transcription block
    manual_transcription = ManualTranscriptionBlock(
        reference_name='manual_transcription',
        submission=machine_transcription.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    def _perform_line_item_validations(
            submission: Any,
            api_params_ref: Any,
            wf_param_skip_fleex: Any,
            wf_param_ignore_transcribed: Any,
    ) -> Any:
        """
            Pseudo Code:
                Iterate submission documents:
                    Initialize invoice total, if total_invoice_amount field transcribed
                    Convert document table to row format from submission columnar format
                    Iterate data rows:
                        Determine transcription results for each row
                        Determine calculations for each row from transcription results
                        Store transcription & calculation results in row_results object
                        For row columns both transcribed and calculated perform validations
                            Mark for Flexible Extraction row columns with differences
                            Mark for IDP Sync columns calculated but not transcribed (future)
                    Mark for Flexible Extraction if line item calculations differ from invoice total
            Dictionary objects:
                row_results: Contains information about transcription/calculation for each row
                document_validation: Contains all row results for the document
                line_item_validation: Contains the results for all documents in the submission
            """

        from typing import Tuple

        import numpy
        import logging

        logger = logging.getLogger(__name__)
        logger.info('table_line_item_validation: _perform_line_item_validations(): entered')

        import locale

        locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')

        TRANSCRIPTION_SOURCE_CUSTOM = 'custom'

        def _my_get_float(value: str) -> float:
            if value != '':
                try:
                    currency_symbol: str = locale.localeconv()['currency_symbol']  # type: ignore
                    return locale.atof(value.strip(currency_symbol))
                except:
                    raise ValueError(f'Could not convert value="{value}" to float')
            else:
                return 0.0

        def _format_column(value: float, column_name: str = '') -> str:
            try:
                lcol = column_name.lower()
                if 'quantity' in lcol or 'unit_price' in lcol:
                    return '{:.4f}'.format(value)
                elif 'total_price' in lcol or 'amount' in lcol:
                    return _my_get_currency(value)
                else:
                    return '{:.2f}'.format(value)
            except Exception as e:
                logger.warning(
                    '_format_column(): error occurred for float value={}, '
                    'column_name={}, error={}',
                    value,
                    column_name,
                    str(e),
                )
                return '0.0'

        def _my_get_currency(value: float) -> str:
            return locale.currency(value, grouping=True)

        def _can_calculate(line_item_data: Dict[str, Any], calc_columns: set) -> bool:
            """
                Shortcut function for determining whether a line item has enough information
                to perform a calculation
                """
            if not calc_columns.issubset(line_item_data.keys()):
                return False
            else:
                for calc_col in calc_columns:
                    if line_item_data[calc_col]['has_value'] is False:
                        return False
            return True

        def _table_columns_to_row_data(document: Any) -> Dict[Tuple[int, int, int], Any]:
            """Converts document table cells to a different format"""
            row_data: Dict[Tuple[int, int, int], Any] = {}

            for column in document.get('table', {}).get('columns', []):
                if column.get('output_name', '') not in CALC_LINE_ITEM_ALL_COLS:
                    continue

                for cell in column.get('cells', []):
                    row_key = (document['id'], cell['page_number'], cell['row_number'])
                    row_data.setdefault(row_key, {}).update(
                        {column['output_name']: cell.get('transcription_normalized', '')}
                    )

            return row_data

        def _get_row_results_transcribed(row_column: Dict[Any, Any]) -> Dict[str, Dict[Any, Any]]:
            """
                Returns a dict for line item columns (Quantity, Unit Price, Total Price) showing
                results of the transcription:
                    * was the field transcribed
                    * does the transcribed field contain a value (i.e. not empty string)
                    * the normalized value
                    * a float representation of the normalized value
            """
            ret: Dict[str, Dict[Any, Any]] = {}
            for col_name in CALC_LINE_ITEM_ALL_COLS:
                if col_name not in row_column:
                    continue

                transcribed = False
                has_value = False

                if row_column.get(col_name):
                    transcribed = True
                    has_value = True
                    normalized: str = row_column.get(col_name, '')
                    ret.update({col_name: {'transcription_normalized': normalized}})
                    try:
                        normalized_float = _my_get_float(normalized)
                    except ValueError as e:
                        # has_value = False
                        normalized_float = 0.0
                        ret.get(col_name, {}).setdefault('exceptions', []).append(
                            f'Transcription error for {col_name}: {str(e)}'
                        )

                    ret.get(col_name, {}).update({'float_value': normalized_float})

                ret.get(col_name, {}).update({'transcribed': transcribed, 'has_value': has_value})

            return ret

        def _get_row_results_calculated(line_item_data: Dict[str, Any]) -> Dict[str, float]:
            """
                Returns a dict for calculations on a line item. Only columns that can be calculated
                are included in the return dict. This serves as an indicator that we can validate
                a line item. IOW, if a column is not present in the row results calculated then we
                can't validate the line item
                """

            if _can_calculate(line_item_data, {'quantity'}):
                try:
                    q = _my_get_float(line_item_data['quantity']['transcription_normalized'])
                except Exception as e:
                    row_results.setdefault('exceptions_calculated', []).append(
                        f'Transcription error for quantity: {str(e)}'
                    )
                    q = 0.0

            if _can_calculate(line_item_data, {'unit_price'}):
                try:
                    u = _my_get_float(line_item_data['unit_price']['transcription_normalized'])
                except Exception as e:
                    row_results.setdefault('exceptions_calculated', []).append(
                        f'Transcription error for unit_price: {str(e)}'
                    )
                    u = 0.0

            if _can_calculate(line_item_data, {'total_price'}):
                try:
                    t = _my_get_float(line_item_data['total_price']['transcription_normalized'])
                except Exception as e:
                    row_results.setdefault('exceptions_calculated', []).append(
                        f'Transcription error for total_price: {str(e)}'
                    )
                    t = 0.0

            ret = {}
            if _can_calculate(line_item_data, CALC_TOTAL_PRICE_COLS):
                ret.update({'total_price': q * u})

            if _can_calculate(line_item_data, CALC_QUANTITY_COLS):
                if u != 0.0:
                    ret.update({'quantity': t / u})

            if _can_calculate(line_item_data, CALC_UNIT_PRICE_COLS):
                if q != 0.0:
                    ret.update({'unit_price': t / q})

            return ret

        def _require_idp_sync(
                column_name: str, row_key: Tuple[int, int, int], transcription_normalized: str
        ) -> None:
            """
                TODO: When/if we merge line item columns that were not transcribed but could be
                    calculated we would then perform IDP sync. Note when performing IDP sync for
                    a table that all rows and columns must be supplied to the IDP sync process.
                """
            line_item_validation.update({'idp_sync': True})
            document_validation.update({'idp_sync': True})

            sync_cell = {
                'column_name': column_name,
                'document_id': row_key[0],
                'page_number': row_key[1],
                'row_number': row_key[2],
                'transcription_normalized': transcription_normalized,
            }

            document_validation.setdefault('sync_columns', []).append(sync_cell)

        def _require_flexible_extraction_for_cell(
                column_name: str, row_key: Tuple[int, int, int], message: str
        ) -> None:
            """
                Marks a table cell for Flexible Extraction. An exception string is appended to
                 the submission, document, and field/table cell.
                """

            line_item_validation.update({'is_valid': False})
            document_validation.update({'is_valid': False})

            if wf_param_skip_fleex is False:
                line_item_validation.update({'flexible_extraction': True})
                document_validation.update({'flexible_extraction': True})

            if column_name and row_key:
                doc_table_col = {}
                doc_table_cell = {}
                for column in document.get('table', {}).get('columns', []):
                    if column['output_name'] == column_name:
                        doc_table_col = column
                        for cell in column.get('cells', []):
                            if (cell['page_number'], cell['row_number']) == (
                                    row_key[1],
                                    row_key[2],
                            ):
                                doc_table_cell = cell
                                break
                        break

                if doc_table_col and doc_table_cell:
                    document_validation.setdefault('columns', []).append(
                        {
                            'field_name': doc_table_col['field_name'],
                            'output_name': column_name,
                            'page_number': row_key[1],
                            'row_number': row_key[2],
                            'flexible_extraction': True,
                            'exceptions': [message],
                        }
                    )

                    if wf_param_skip_fleex is False:
                        doc_table_cell['process_flexible_extraction_type'] = 'FORCE'
                        doc_table_cell['needs_flexible_extraction_review'] = True

                    doc_table_cell['transcription_source'] = TRANSCRIPTION_SOURCE_CUSTOM
                    if message:
                        doc_table_cell.setdefault('exceptions', []).append(message)
                        document.setdefault('exceptions', []).append(message)
                        submission.setdefault('exceptions', []).append(
                            f'page_{row_key[1]}_row_{row_key[2]}: {message}'
                        )
            return

        def _require_flexible_extraction_reason(reason: str) -> None:
            """
                Marks the document for Flexible Extraction. The reason is added as an exception
                """

            line_item_validation.update({'is_valid': False})
            document_validation.update({'is_valid': False})

            line_item_validation.update({'flexible_extraction': True})
            document_validation.update({'flexible_extraction': True})

            if reason:
                if reason not in document_validation.get('reasons', []):
                    document_validation.setdefault('reasons', []).append(reason)
                    document.setdefault('exceptions', []).append(reason)
                    submission.setdefault('exceptions', []).append(reason)

            return

        def _require_flexible_extraction_for_field(
                field_id: int, reason: str = '', message: str = ''
        ) -> None:
            """
                Marks the document_field for Flexible Extraction. An exception string is appended
                 to the submission, document, and field/table cell.
                """
            line_item_validation.update({'is_valid': False})
            document_validation.update({'is_valid': False})

            line_item_validation.update({'flexible_extraction': True})
            document_validation.update({'flexible_extraction': True})

            if reason:
                if reason not in document_validation.get('reasons', []):
                    document_validation.setdefault('reasons', []).append(reason)
                    document.setdefault('exceptions', []).append(reason)
                    submission.setdefault('exceptions', []).append(
                        f'document id={document["id"]}; {reason}'
                    )

            if message:
                if message not in document_validation.get('exceptions', []):
                    document_validation.setdefault('exceptions', []).append(message)
                    document.setdefault('exceptions', []).append(message)
                    submission.setdefault('exceptions', []).append(
                        f'document id={document["id"]}; {message}'
                    )
                    line_item_validation.setdefault('exceptions', []).append(message)

            if field_id:
                if 'fields' in document_validation:
                    validation_field: Dict[Any, Any] = [
                        field
                        for field in document_validation.get('fields', [])
                        if field['field_id'] == field_id
                    ][0]
                    if validation_field:
                        if reason and reason not in validation_field.get('reasons', []):
                            validation_field.setdefault('reasons', []).append(reason)
                        if message and message not in validation_field.get('exceptions', []):
                            validation_field.setdefault('exceptions', []).append(message)
                        else:
                            validation_field.setdefault('exceptions', []).append(reason)
                        return

                doc_field = [
                    field for field in document.get('document_fields') if field['id'] == field_id
                ][0]

                if doc_field:
                    document_validation.setdefault('fields', []).append(
                        {
                            'field_id': field_id,
                            'name': doc_field['field_name'],
                            'output_name': doc_field['output_name'],
                            'flexible_extraction': True,
                            'reasons': [reason],
                            'exceptions': [message],
                        }
                    )

                    if wf_param_skip_fleex is False:
                        doc_field['process_flexible_extraction_type'] = 'FORCE'
                        doc_field['needs_flexible_extraction_review'] = True

                    doc_field['transcription_source'] = TRANSCRIPTION_SOURCE_CUSTOM

            return

        CALC_LINE_ITEM_ALL_COLS = {'quantity', 'unit_price', 'total_price'}

        CALC_TOTAL_PRICE_COLS = {'quantity', 'unit_price'}
        CALC_QUANTITY_COLS = {'unit_price', 'total_price'}
        CALC_UNIT_PRICE_COLS = {'quantity', 'total_price'}

        line_item_validation: Dict[Any, Any] = {}

        for document in submission.get('documents', []):
            document_validation: Dict[Any, Any] = {'is_valid': True, 'flexible_extraction': False}

            invoice: Dict[Any, Any] = {'running_total': 0.0}

            # Initialize invoice total, if total_invoice_amount field transcribed
            for field in document.get('document_fields', []):
                if field.get('output_name') == 'total_invoice_amount':
                    logger.info('table_line_item_validation: found total_invoice_amount')
                    if field.get('transcription_normalized'):
                        try:
                            total_invoice_amount = _my_get_float(field['transcription_normalized'])
                        except ValueError as e:
                            total_invoice_amount = 0.0
                            msg = f'Transcription error for total_invoice_amount: {str(e)}'
                            _require_flexible_extraction_for_field(
                                field['id'], 'total_invoice_amount_transcription_error', msg
                            )

                        invoice.update(
                            {'total_invoice_amount': total_invoice_amount or 0.0, 'field': field}
                        )

            if 'table' not in document:
                continue

            if not line_item_validation:
                # initialize line_item_validation first time we encounter a document
                # assume document is valid and fleex is not required
                line_item_validation = {'is_valid': True, 'flexible_extraction': False}

            line_item_columns = [
                column
                for column in document.get('table', {}).get('columns', [])
                if column['output_name'] in CALC_LINE_ITEM_ALL_COLS
            ]

            if not line_item_columns:
                logger.info('No line item validation columns found in table')
                document.setdefault('exceptions', []).append(
                    f'No line item validation columns found in table: {CALC_LINE_ITEM_ALL_COLS}'
                )
                document_validation.setdefault('exceptions', []).append(
                    f'No line item validation columns found in table: {CALC_LINE_ITEM_ALL_COLS}'
                )
                line_item_validation.setdefault('exceptions', []).append(
                    f'No line item validation columns found in table: document id={document["id"]}'
                )
                continue

            # Convert document table to row format from submission columnar format
            #
            #   row_key is Tuple(document['id'], cell['page_number'], cell['row_number'])
            #       {
            #           output_name: transcription_normalized
            #       }
            #
            row_data = _table_columns_to_row_data(document)

            if not row_data:
                document.setdefault('exceptions', []).append(
                    'No table row data available for validations'
                )
                document_validation.setdefault('exceptions', []).append(
                    'No table row data available for validations'
                )
                line_item_validation.setdefault('exceptions', []).append(
                    'No table row data available for validations for document id '
                    f'{document["id"]}'
                )

            for row_key, row_data_info in row_data.items():
                row_results: Dict[Any, Any] = {
                    'all_transcribed': False,
                    'columns_transcribed': set(),
                    'columns_not_transcribed': set(),
                    'exceptions_transcribed': [],
                    'all_calculated': False,
                    'columns_calculated': set(),
                    'columns_not_calculated': set(),
                    'exceptions_calculated': [],
                }

                # Determine transcription results for each row
                line_item_transcribed = _get_row_results_transcribed(row_data_info)

                # a set containing only columns that were transcribed
                columns_transcribed = {
                    col_name
                    for col_name, col_info in line_item_transcribed.items()
                    if col_info['transcribed']
                }
                columns_not_transcribed = CALC_LINE_ITEM_ALL_COLS.difference(columns_transcribed)

                transcription_exceptions = [
                    f'id_{row_key[0]}_page_{row_key[1]}_row_{row_key[2]}: {s}'
                    for v in line_item_transcribed.values()
                    for s in v.get('exceptions', [])
                ]

                # the CustomSetting doesn't apply to errors for fields
                # that have been transcribed
                #
                # the CustomSetting prevents errors when a line item field was not found
                if transcription_exceptions:
                    document_validation.setdefault('exceptions', []).extend(
                        transcription_exceptions
                    )
                    line_item_validation.setdefault('exceptions', []).extend(
                        transcription_exceptions
                    )

                # add the line item amount to the running total
                if 'total_price' in line_item_transcribed:
                    total_price_exceptions = line_item_transcribed.get('total_price', {}).get(
                        'exceptions', []
                    )
                    if len(total_price_exceptions) > 0:
                        _require_flexible_extraction_for_cell(
                            'total_price', row_key, ','.join(total_price_exceptions)
                        )

                    if line_item_transcribed.get('total_price', {}).get('has_value', False):
                        invoice.update(
                            {
                                'running_total': invoice['running_total']
                                                 + line_item_transcribed['total_price'][
                                                     'float_value']
                            }
                        )

                # Determine calculations for each row from transcription results
                # Calculate line item columns based on transcription results
                #
                # a column is only present in line_item_calculated if it can be calculated
                #
                line_item_calculated = _get_row_results_calculated(line_item_transcribed)

                columns_calculated = set(line_item_calculated.keys())
                columns_not_calculated = CALC_LINE_ITEM_ALL_COLS.difference(columns_calculated)

                # Store transcription & calculation results in row_results object
                #
                # sets are converted to lists since sets cannot be serialized which results in a
                # TypeError during flow execution
                #
                row_results.update(
                    {
                        'all_transcribed': columns_transcribed == CALC_LINE_ITEM_ALL_COLS,
                        'columns_transcribed': list(columns_transcribed),
                        'columns_not_transcribed': list(columns_not_transcribed),
                        'exceptions_transcribed': transcription_exceptions,
                        'all_calculated': line_item_calculated.keys() == CALC_LINE_ITEM_ALL_COLS,
                        'columns_calculated': list(columns_calculated),
                        'columns_not_calculated': list(columns_not_calculated),
                    }
                )

                # For row columns both transcribed and calculated perform validations
                for col_name in columns_transcribed.intersection(columns_calculated):
                    transcribed_value = line_item_transcribed[col_name]['float_value']
                    calculated_value = line_item_calculated[col_name]
                    difference = transcribed_value - calculated_value
                    row_results.update(
                        {
                            col_name: {
                                'transcribed_value': transcribed_value,
                                'calculated_value': _format_column(calculated_value, col_name),
                                'difference': _format_column(difference, col_name),
                            }
                        }
                    )

                    if not numpy.isclose(calculated_value, transcribed_value):
                        message = (
                            f'{col_name}: value_difference; transcribed='
                            f'{_format_column(transcribed_value, col_name)}, '
                            f'calculated={_format_column(calculated_value, col_name)}, '
                            f'difference={_format_column(difference, col_name)}'
                        )

                        _require_flexible_extraction_for_cell(col_name, row_key, message)

                if wf_param_ignore_transcribed is False:
                    #
                    # Mark for IDP Sync columns calculated but not transcribed
                    #
                    # For example, unit price & total price were transcribed but quantity
                    # was not. The quantity can be calculated and the added to the row
                    #
                    # TODO: if we've calculated columns that were not transcribed we can
                    #   add them through IDP sync. If the invoice total validation fails
                    #   then also send the added row cell to flexible extraction
                    for col_name in columns_calculated.difference(columns_transcribed):
                        # this column was calculated but not transcribed - add it via IDP sync later
                        _require_idp_sync(
                            col_name,
                            row_key,
                            _format_column(line_item_calculated[col_name], col_name),
                        )
                        row_results.get('idp_sync_cols', []).append(col_name)

                    if not row_results['all_transcribed']:
                        _require_flexible_extraction_reason('columns_not_transcribed')

            # Mark for Flexible Extraction if line item calculations differ from invoice total
            if 'total_invoice_amount' in invoice:
                document_validation.update(
                    {
                        'total_amount': _format_column(invoice['total_invoice_amount']),
                        'line_item_total_amount': _format_column(invoice['running_total']),
                    }
                )

                if numpy.isclose(invoice['running_total'], 0.0):

                    _require_flexible_extraction_reason('could_not_calculate_total_invoice_amount')

                elif not numpy.isclose(invoice['total_invoice_amount'], invoice['running_total']):

                    document_validation.update(
                        {
                            'total_difference': _format_column(
                                invoice['total_invoice_amount'] - invoice['running_total']
                            )
                        }
                    )

                    message = (
                        'Line item total does not equal invoice total: '
                        f'{invoice["field"]["field_name"]}={invoice["total_invoice_amount"]} '
                        '(Transcribed); '
                        f'Line Item Total={_format_column(invoice["running_total"])} '
                        '(Calculated); '
                        f'Difference={document_validation["total_difference"]}; '
                    )

                    _require_flexible_extraction_for_field(
                        field_id=invoice['field']['id'],
                        message=message,
                        reason='total_invoice_amount_difference',
                    )
            else:
                document_validation.update({'is_valid': False})
                document_validation.setdefault('exceptions', []).append(
                    'Could not locate field output_name=total_invoice_amount'
                )
                line_item_validation.update({'is_valid': False})
                line_item_validation.setdefault('exceptions', []).append(
                    'Could not locate field output_name=total_invoice_amount '
                    f'for document id: {document["id"]}'
                )

            # set to fleex when it's required and the skip param is false
            if (
                    document_validation.get('flexible_extraction', False)
                    and wf_param_skip_fleex is False
            ):
                document['needs_flexible_extraction_review'] = True

            line_item_validation.update({f'doc_{document["id"]}': document_validation})
            if document_validation.get('is_valid', True) is False:
                line_item_validation.update({'is_valid': False})

        if 'is_valid' not in line_item_validation:
            # no documents were processed when is_valid is not in line_item_validation
            line_item_validation.update({'is_valid': False})
            line_item_validation.setdefault('exceptions', []).append(
                'No validations occurred due ' 'to incomplete submission data'
            )

        submission.update({'line_item_validation': line_item_validation})

        logger.info('table_line_item_validation: _perform_line_item_validations(): returned')

        return {'submission': submission, 'line_item_validation': line_item_validation}

    line_item_validation = CodeBlock(
        reference_name='perform_validate_line_items',
        code=_perform_line_item_validations,
        code_input={
            'submission': manual_transcription.output('submission'),
            'api_params_ref': submission_bootstrap.output('result.api_params'),
            'wf_param_skip_fleex': workflow_input(CustomSettings.SkipFlexibleExtraction),
            'wf_param_ignore_transcribed': workflow_input(
                CustomSettings.IgnoreLineItemTranscription
            )
        },
        title='Validate Line Items',
        description='Validates the Invoice''s Line Items',
    )

    # Flexible extraction manually transcribes fields marked for review
    # In this example, flexible extraction block receives the submission object from manual
    # transcription block
    flexible_extraction = FlexibleExtractionBlock(
        reference_name='flexible_extraction',
        submission=line_item_validation.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    def _load_submission(submission: Any) -> Any:
        import inspect

        submission_id_ref = submission['id']
        proxy = inspect.stack()[1].frame.f_locals['proxy']
        r = proxy.sdm_get(f'api/v5/submissions/{submission_id_ref}?flat=False')
        return r.json()

    load_submission = CodeBlock(
        reference_name='load_submission',
        code=_load_submission,
        code_input={'submission': flexible_extraction.output('submission')},
        title='Load Submission',
        description='Returns Submission in API v5 Format',
    )

    def _mark_as_complete(submission: Any, line_item_validation: Any) -> Any:
        if line_item_validation:
            submission.update({'line_item_validation': line_item_validation})

        from datetime import datetime

        dt_completed = datetime.isoformat(datetime.utcnow())
        dt_completed_fmt = dt_completed + 'Z'

        for document in submission.get('documents', []):
            document['state'] = 'complete'
            document['complete_time'] = dt_completed_fmt

            for page in document.get('pages', []):
                page['state'] = 'complete'

            for field in document.get('document_fields', []):
                field['state'] = 'complete'

            for cell in [
                cell
                for document_table in document.get('document_tables', [])
                for row in document_table.get('rows', [])
                for cell in row.get('cells', [])
            ]:
                cell['state'] = 'complete'

        for page in submission.get('unassigned_pages', []):
            page['state'] = 'complete'

        if 'state' in submission:
            submission['state'] = 'complete'
        if 'complete_time' in submission:
            submission['complete_time'] = dt_completed_fmt

        return submission

    # Custom code block enables users to transform and validate extracted submission data
    # before Hyperscience sends it to downstream systems
    # In this example, user created a _mark_as_completed function to transform and validate
    # submission data
    # Notice that the _mark_as_completed function takes in a single argument which is passed
    # in using the code_input parameter
    mark_as_complete = CodeBlock(
        reference_name='mark_as_completed',
        code=_mark_as_complete,
        code_input={
            'submission': load_submission.output(),
            'line_item_validation': line_item_validation.output('line_item_validation')
                    },
        title='Mark As Completed',
        description='Updated Transformed JSON to Completed State',
    )

    # Submission complete block finalizes submission processing and updates reporting data
    # Every flow needs a complete block because it initiates Quality Assurance tasks and
    # changes the submission's status to "Complete"
    # In this example, submission complete block receives the submission object from
    # marked_as_complete custom code block
    submission_complete = SubmissionCompleteBlock(
        reference_name='complete_submission',
        payload=mark_as_complete.output(),
        submission=mark_as_complete.output()
    )

    # Output block allows users to send data extracted by this idp flow to other systems
    # for downstream processing
    # In this example, this is an empty output block that does not do anything by default
    outputs = IDPOutputsBlock(
        inputs={'submission': submission_bootstrap.output('result.submission')}
    )

    invoice_flow = Flow(
        # Flows should have a deterministic UUID ensuring cross-system consistency
        uuid=UUID('749bbcfa-020f-428f-8878-b1206e2a4d79'),
        owner_email='chris.card@hyperscience.com',
        title='Line Item Validations',
        # Flow identifiers are globally unique
        manifest=IDPManifest(flow_identifier='LINE_ITEM_VALIDATION'),
        # It is important to include all blocks that are instantiated here in the blocks
        # field and make sure they follow the order of the flow. For example, if machine
        # classification depends on the output of case collation, then case_collation must
        # come before machine_classification in this blocks array
        blocks=[
            submission_bootstrap,
            case_collation,
            machine_classification,
            manual_classification,
            machine_identification,
            manual_identification,
            machine_transcription,
            manual_transcription,
            line_item_validation,
            flexible_extraction,
            load_submission,
            mark_as_complete,
            submission_complete,
            outputs,
        ],
        input=get_idp_wf_inputs(idp_wf_config),
        description='Perform validation for total invoice amount and for line item quantity, '
        'unit price, and total price',
        triggers=IDPTriggers(),
        output={'submission': submission_complete.output()},
    )

    inputs: List[Parameter] = invoice_flow.manifest.input or []
    for i in LINE_ITEM_VALIDATION_PARAMETERS:
        inputs.append(i)

    wf_input: Optional[Dict[str, Any]] = invoice_flow.input
    # avoid mypy error 'has no attribute update'
    assert wf_input is not None

    wf_input.update(
        {
            CustomSettings.SkipFlexibleExtraction: False,
            CustomSettings.IgnoreLineItemTranscription: False,
        }
    )

    return invoice_flow


if __name__ == '__main__':
    export_flow(flow=entry_point_flow())
